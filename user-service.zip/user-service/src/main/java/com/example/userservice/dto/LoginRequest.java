public class LoginRequest {
    public String username;
    public String password;
}
